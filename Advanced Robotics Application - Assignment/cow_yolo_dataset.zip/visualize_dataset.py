import os
import random
from pathlib import Path

import cv2
import matplotlib.pyplot as plt
import numpy as np

# ---------------- CONFIG ----------------
DATASET_ROOT = Path(
    "/home/sanket758/Education/BSBI/Advanced Robotics Application/3d-cows/cow_yolo_dataset"
)

SPLITS = ["train", "val"]
NUM_IMAGES = 6

POINT_RADIUS = 4
FONT_SCALE = 0.4
FONT_THICKNESS = 1

VISIBLE_COLOR = (0, 255, 0)  # green
OCCLUDED_COLOR = (0, 165, 255)  # orange
EDGE_COLOR = (255, 0, 0)  # blue
TEXT_COLOR = (255, 255, 255)

# -------------------------------------------------
# KEYPOINT INDEX (from your dataset.yaml comment)
#
#  0  L_Eye          13 R_B_Elbow
#  1  R_Eye          14 L_F_Knee
#  2  Nose           15 R_F_Knee
#  3  L_EarBase      16 L_B_Knee
#  4  R_EarBase      17 R_B_Knee
#  5  L_EarTip       18 L_F_Paw
#  6  R_EarTip       19 R_F_Paw
#  7  Throat         20 L_B_Paw
#  8  Withers        21 R_B_Paw
#  9  L_F_Elbow      22 TailBase
# 10  R_F_Elbow      23 Spine1
# 11  L_B_Elbow      24 Spine2
# 12  R_B_Elbow      25 Spine3
#
# -------------------------------------------------

# -------------------------------------------------
# KEYPOINT INDEX (Observed from Diagnostic Images)
#
#  0  L_Eye          13 Withers (Shoulders)
#  1  R_Eye          14 L_F_Knee
#  2  Chin           15 R_F_Knee
#  3  L_F_Hoof       16 L_B_Knee (Hock)
#  4  R_F_Hoof       17 R_B_Knee (Hock)
#  5  L_B_Hoof       18 Throat
#  6  R_B_Hoof       19 Tail_Tip
#  7  Tail_Base      20 L_EarBase
#  8  Shoulder_Blade 21 R_EarBase
#  9  Elbow          22 Mouth_Corner
# 10  Hip_HookBone   23 Nose_Tip
# 11  Hip_Stifle     24 Nose_Bridge
# 12  Spine_Mid      25 Tail_Mid
#
# -------------------------------------------------

# # Skeleton edges (EDIT THIS if mapping looks wrong)
# SKELETON = [
#     # Head
#     (0, 2),
#     (1, 2),
#     (0, 3),
#     (1, 4),
#     (3, 5),
#     (4, 6),
#     (2, 7),
#     # Spine
#     (7, 8),
#     (8, 23),
#     (23, 24),
#     (24, 25),
#     (25, 22),
#     # Front legs
#     (8, 9),
#     (9, 14),
#     (14, 18),
#     (8, 10),
#     (10, 15),
#     (15, 19),
#     # Back legs
#     (23, 11),
#     (11, 16),
#     (16, 20),
#     (23, 12),
#     (12, 17),
#     (17, 21),
# ]

# Skeleton edges (Corrected for the observed mapping)
# SKELETON = [
#     # Face Structure
#     (23, 24),  # Nose Tip -> Nose Bridge
#     (24, 0),  # Bridge -> L Eye
#     (24, 1),  # Bridge -> R Eye
#     (0, 20),  # L Eye -> L Ear
#     (1, 21),  # R Eye -> R Ear
#     (23, 2),  # Nose Tip -> Chin
#     (2, 18),  # Chin -> Throat
#     # Spine Chain
#     (18, 13),  # Throat -> Withers
#     (13, 12),  # Withers -> Spine Mid
#     (12, 7),  # Spine Mid -> Tail Base
#     (7, 25),  # Tail Base -> Tail Mid
#     (25, 19),  # Tail Mid -> Tail Tip
#     # Front Legs (Connecting from Withers)
#     (13, 14),  # Withers -> L Front Knee
#     (14, 3),  # L Front Knee -> L Front Hoof
#     (13, 15),  # Withers -> R Front Knee
#     (15, 4),  # R Front Knee -> R Front Hoof
#     # Back Legs (Connecting from Tail Base/Hip area)
#     (7, 16),  # Tail Base -> L Back Knee
#     (16, 5),  # L Back Knee -> L Back Hoof
#     (7, 17),  # Tail Base -> R Back Knee
#     (17, 6),  # R Back Knee -> R Back Hoof
#     # Optional Body Volume (Side points)
#     (13, 8),  # Withers -> Shoulder Blade
#     (8, 9),  # Shoulder Blade -> Elbow
#     (12, 10),  # Spine Mid -> Hip Hook
#     (10, 11),  # Hip Hook -> Stifle
# ]

# Keypoint names (Matched to visual evidence)

keypoint_names = [
    "L_Eye",  # 0
    "R_Eye",  # 1
    "Chin",  # 2
    "R_F_Hoof",  # 3
    "L_F_Hoof",  # 4
    "R_B_Hoof",  # 5
    "L_B_Hoof",  # 6
    "Tail_Base",  # 7
    "R_Shoulder",  # 8
    "L_Shoulder",  # 9
    "R_Hip",  # 10
    "L_Hip",  # 11
    "Spine_Mid",  # 12
    "Withers",  # 13
    "R_F_Knee",  # 14
    "L_F_Knee",  # 15
    "R_B_Knee",  # 16  (Hock)
    "L_B_Knee",  # 17  (Hock)
    "Throat",  # 18
    "Tail_Tip",  # 19
    "L_EarBase",  # 20
    "R_EarBase",  # 21
    "Mouth_Corner",  # 22
    "Nose_Tip",  # 23
    "Nose_Bridge",  # 24
    "Tail_Mid",  # 25
]

# Verified Skeleton (Derived from red lines in screenshots)
SKELETON = [
    # --- Head Mesh ---
    (23, 24),  # Nose Tip -> Nose Bridge
    (24, 22),  # Nose Bridge -> Mouth Corner
    (22, 2),  # Mouth Corner -> Chin
    (23, 2),  # Nose Tip -> Chin
    (24, 1),  # Nose Bridge -> R Eye
    (24, 0),  # Nose Bridge -> L Eye
    (1, 21),  # R Eye -> R Ear
    (0, 20),  # L Eye -> L Ear
    (18, 21),  # Throat -> R Ear
    (18, 20),  # Throat -> L Ear
    (18, 2),  # Throat -> Chin
    # --- Spine Chain ---
    (18, 13),  # Throat -> Withers
    (13, 12),  # Withers -> Spine Mid
    (12, 7),  # Spine Mid -> Tail Base
    (7, 25),  # Tail Base -> Tail Mid
    (25, 19),  # Tail Mid -> Tail Tip
    # --- Front Legs (Anchored at Spine_Mid 12) ---
    (12, 8),  # Spine Mid -> R Shoulder
    (8, 14),  # R Shoulder -> R Knee
    (14, 3),  # R Knee -> R Hoof
    (12, 9),  # Spine Mid -> L Shoulder
    (9, 15),  # L Shoulder -> L Knee
    (15, 4),  # L Knee -> L Hoof
    # --- Back Legs (Anchored at Tail_Base 7) ---
    (7, 10),  # Tail Base -> R Hip
    (10, 16),  # R Hip -> R Hock
    (16, 5),  # R Hock -> R Hoof
    (7, 11),  # Tail Base -> L Hip
    (11, 17),  # L Hip -> L Hock
    (17, 6),  # L Hock -> L Hoof
    # --- Cross Connections ---
    (8, 9),  # Shoulder -> Shoulder
    (10, 11),  # Hip -> Hip
]


def load_yolo_pose_label(label_path, img_w, img_h):
    """
    Returns: list of keypoints [(x, y, v), ...]
    """
    all_instances = []

    with open(label_path, "r") as f:
        for line in f:
            parts = list(map(float, line.strip().split()))
            kp_data = parts[5:]  # skip class + bbox

            kps = []
            for i in range(0, len(kp_data), 3):
                x = int(kp_data[i] * img_w)
                y = int(kp_data[i + 1] * img_h)
                v = int(kp_data[i + 2])
                kps.append((x, y, v))

            all_instances.append(kps)

    return all_instances


def visualize_image(img_path, label_path, save_path):
    img = cv2.imread(str(img_path))
    img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    h, w = img.shape[:2]

    instances = load_yolo_pose_label(label_path, w, h)

    for kps in instances:
        # ---- Draw skeleton edges ----
        for i, j in SKELETON:
            xi, yi, vi = kps[i]
            xj, yj, vj = kps[j]

            if vi > 0 and vj > 0:
                cv2.line(img, (xi, yi), (xj, yj), EDGE_COLOR, 2)

        # ---- Draw keypoints + index ----
        for idx, (x, y, v) in enumerate(kps):
            if v == 0:
                continue

            color = VISIBLE_COLOR if v == 2 else OCCLUDED_COLOR
            cv2.circle(img, (x, y), POINT_RADIUS, color, -1)

            cv2.putText(
                img,
                str(idx),
                (x + 5, y - 5),
                cv2.FONT_HERSHEY_SIMPLEX,
                FONT_SCALE,
                TEXT_COLOR,
                FONT_THICKNESS,
                cv2.LINE_AA,
            )

    plt.figure(figsize=(9, 6))
    plt.imshow(img)
    plt.axis("off")
    plt.tight_layout()
    plt.savefig(save_path, dpi=150)
    plt.close()


def main():
    vis_dir = DATASET_ROOT / "visualizations"
    vis_dir.mkdir(exist_ok=True)

    pairs = []

    for split in SPLITS:
        img_dir = DATASET_ROOT / "images" / split
        lbl_dir = DATASET_ROOT / "labels" / split

        for img_path in img_dir.glob("*.*"):
            lbl_path = lbl_dir / f"{img_path.stem}.txt"
            if lbl_path.exists():
                pairs.append((img_path, lbl_path))

    assert pairs, "No image-label pairs found."

    samples = random.sample(pairs, min(NUM_IMAGES, len(pairs)))

    for i, (img, lbl) in enumerate(samples):
        out = vis_dir / f"vis_{i:02d}_{img.name}"
        visualize_image(img, lbl, out)

    print(f"[OK] Saved {len(samples)} images to {vis_dir}")


if __name__ == "__main__":
    main()
